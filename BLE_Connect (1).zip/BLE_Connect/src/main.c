/*==================================================================================================

*   Project              : RTD AUTOSAR 4.7

*   Platform             : CORTEXM

*   Peripheral           : S32K3XX

*   Dependencies         : none

*

*   Autosar Version      : 4.7.0

*   Autosar Revision     : ASR_REL_4_7_REV_0000

*   Autosar Conf.Variant :

*   SW Version           : 3.0.0

*   Build Version        : S32K3_RTD_3_0_0_D2303_ASR_REL_4_7_REV_0000_20230331

*

*   Copyright 2020 - 2023 NXP Semiconductors

*

*   NXP Confidential. This software is owned or controlled by NXP and may only be

*   used strictly in accordance with the applicable license terms. By expressly

*   accepting such terms or by downloading, installing, activating and/or otherwise

*   using the software, you are agreeing that you have read, and that you agree to

*   comply with and are bound by, such license terms. If you do not agree to be

*   bound by the applicable license terms, then you may not retain, install,

*   activate or otherwise use the software.

==================================================================================================*/

/**

*   @file main.c

*

*   @addtogroup main_module main module documentation

*   @{

*/

#include "Mcal.h"
#include "Clock_Ip.h"
#include "Lpuart_Uart_Ip.h"
#include "Siul2_Port_Ip.h"
#include "Siul2_Dio_Ip.h"
#include "Siul2_Icu_Ip.h"
#include "IntCtrl_Ip.h"
#include "Siul2_Port_Ip_Cfg.h"
#include "Siul2_Dio_Ip_Cfg.h"
#include "Siul2_Icu_Ip_SA_PBcfg.h"
#include "Siul2_Icu_Ip_Irq.h"
#include "Lpuart_Uart_Ip_Irq.h"
#include "IntCtrl_Ip_Cfg.h"
#include "Stm_Ip.h"
#include "Stm_Ip_Cfg.h"
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

/* User variables */
bool Door_Swstate = false;
bool Veh_Swstate  = false;
volatile int exit_code = 0;
/* Define channel */
#define UART_LPUART_INTERNAL_CHANNEL  3

//#define UART_LPUART_INTERNAL_CHANNEL 3
#define UART_TIMEOUT                  1000U
#define ERROR_MSG                     "An error occurred! The application will stop!\r\n"
#define LED_PORT                      PTF_L_HALF
#define PTF_8                         8
#define PTF_9                         9
//#define BUFFER_SIZE 				  6
#define TIMEOUT_MS    2000  // 2 seconds timeout
char Send_Buff[15];
static char RxBuff[13] = {0};
uint8_t Resp_Cm = 0;
uint8_t  Rx_Buff_Status = 0;
//bool response_command;
uint8_t bufferIdx=0;
char Reset_flag=0;
char rep[]="N/A\r\n";
char rep1[]="00\r\n";
size_t data_length=0;
uint8 instance = 0U;
uint8 channel = 0U;
uint32 compareValue = 48000U;
void mSec_timer1(unsigned int mSecTime);
void Sec1_Timer(unsigned int SecTime);
/* Timer variables */
unsigned int mSec_Counter=0,Sec_Cnt=0,mSec1_Counter=0,mSec2_Counter=0, mSec3_Counter=0;
unsigned char mSec1Flag=false,mSec2Flag=false,mSec3Flag=false,Sec1_Flag=true;

uint8_t  response_command;
/* Command enum */
enum Command_Prompt {
    Cmd_Prompt = 0,
    Addressing_Mode,
    Door_Key,
    Vehicle_Key,
    Key_reset_DOOR_Key,
    Key_reset_VEHICLE_Key
};
/* BLE commands */
char Buffer_BLE[][16]={
		"$$$",
	    "A\r\n",
	    "SHR,0072\r\n",
	    "SHR,0075\r\n",
		"SHW,0072,00\r\n",
		"SHW,0075,00\r\n"
     };

char Resp_Ble[][5]={ "CMD>",
		"AOK\r\n",
		"ERR"
		};
enum VARIABLES
{
	FAIL=0,
	SUCCESS,
	UNLOCK
};

char Door_Key_Value[] ="3132";
char Vehicle_Key_Value[]="123456";

/* Function prototypes */
void LPUART3_IRQHandler(void);
void SW0_Callback(void);
void SW1_Callback(void);
uint8_t LUART_Receive(void);
void LUART_Send(char Local_Buffer[]);
uint8_t Send_Commands(uint8_t index);
uint8_t Door_Auth_key(void);
uint8_t Vehicle_Auth_key(void);
void Lpuart_Callback(const uint8 HwInstance, const Lpuart_Uart_Ip_EventType Event, void *UserData);


bool wait_Flag_Timeout(volatile bool *flag)
{
    uint32_t timeoutCounter = 0;
    while (!(*flag) && timeoutCounter < TIMEOUT_MS)
    {
        timeoutCounter++;
    }
    return (*flag); // true if flag was set, false if timeout occurred
}


void mSec_timer1(unsigned int mSecTime)
{
	unsigned int Cnt=1000;
	mSec1_Counter=mSec_Counter+mSecTime;//Ex.700ms+800ms=1500ms
	if(mSec1_Counter >= Cnt)//1500ms>=1000
	{
		mSec1_Counter=mSec1_Counter-1000;//1500ms-1000ms=500ms
	}
}

void mSec_timer2(unsigned int mSecTime)
{
	unsigned int Cnt=60;
	mSec_Counter=0;
	mSec2_Counter=mSec_Counter+mSecTime;//Ex.16s+5s=21s
	if(mSec2_Counter >= Cnt)//(21>=60)
	{
		mSec2_Counter=mSec2_Counter-60;
	}

}

void Stm_Callback(uint8 channel)
{

//	// Re-arm STM for next 1ms
//	    uint32_t currentCount = Stm_Ip_GetCounterValue(0U);
	   // Stm_Ip_StartCounting(0U, 0U, 48000U);  // 1ms at 48MHz
	 	    mSec_Counter++;//increment the mSec_Counter variable for every 1ms.
	 	    if(mSec_Counter==1000)
	 	    {
	 	    	mSec_Counter=0;
	 	    	Sec_Cnt++;//increment the Sec_Cnt variable for every 1000ms.
	 	    }
	 	    if(Sec_Cnt>=60)
	 	    	Sec_Cnt=0;

	 	    if(mSec1_Counter==mSec_Counter)//(500ms==mSec_Counter(500))then set the mSec1Flag flag.
	 	    		{
	 	    			mSec1Flag=true;//when provided delay value reaches set the mSec1Flag flag true.
	 	    			mSec1_Counter=10000;
	 	    		}
	 		if(mSec2_Counter==mSec_Counter)
	 			{
	 				mSec2Flag=true;//when provided delay value matches set the mSec2Flag flag true.
	 				mSec2_Counter=10000;
	 			}
	 }


/* Main function */
int main(void)
{
	/* Write your code here */
	Clock_Ip_Init(&Clock_Ip_aClockConfig[0]);
	Siul2_Port_Ip_Init(NUM_OF_CONFIGURED_PINS0, g_pin_mux_InitConfigArr0);
	Siul2_Icu_Ip_Init(0,&Siul2_Icu_Ip_0_Config_PB);

	Siul2_Port_Ip_Init(NUM_OF_CONFIGURED_PINS0, g_pin_mux_InitConfigArr0);
	/* Initialize IRQs */
	IntCtrl_Ip_Init(&IntCtrlConfig_0);

	// Initialize STM instance
	Stm_Ip_Init(instance, &STM_0_InitConfig_PB);
	// Initialize channel
	Stm_Ip_InitChannel(instance, &STM_0_ChannelConfig_PB[channel]);
   // Start counting
	Stm_Ip_StartCounting(0U, 0U, 48000U);
	/* Start STM channel */
	//Stm_Ip_EnableChannel(0, channel);
	//Stm_Ip_StartTimer(instance,compareValue);
	/* Initialize LPUART with PB config */
	Lpuart_Uart_Ip_Init(UART_LPUART_INTERNAL_CHANNEL, &Lpuart_Uart_Ip_xHwConfigPB_3);

    /* Enable interrupts for switches */
    Siul2_Icu_Ip_EnableInterrupt(0, 16);
    Siul2_Icu_Ip_EnableNotification(0, 16);
    Siul2_Icu_Ip_EnableInterrupt(0, 17);
    Siul2_Icu_Ip_EnableNotification(0, 17);

    /* Main loop */
    while(1)
    {
    	  if(Door_Swstate==true)
    	  {
    		  Door_Swstate=false;
    		  Door_Auth_key();
    	  }
    	  else if(Veh_Swstate==true)
    	  {
    		  Veh_Swstate=false;
    		  Vehicle_Auth_key();
    	  }
    }
}

/* UART IRQ handler */
void LPUART3_IRQHandler(void)
{
    Lpuart_Uart_Ip_IrqHandler(UART_LPUART_INTERNAL_CHANNEL);
}

/* Switch call backs */
void SW0_Callback(void)
{
	Door_Swstate = true;
}
void SW1_Callback(void)
{
	Veh_Swstate = true;
}

/* UART receive using callback */

uint8_t LUART_Receive()
{

	Lpuart_Uart_Ip_StatusType lpuartStatus = LPUART_UART_IP_STATUS_ERROR;
	uint32_t bytesRemaining = 0;
	memset(RxBuff, 0, sizeof(RxBuff));
	Lpuart_Uart_Ip_AsyncReceive(UART_LPUART_INTERNAL_CHANNEL, (unsigned char *)RxBuff, 1U);
	    /* Wait until all bytes are received */
	    while(Lpuart_Uart_Ip_GetReceiveStatus(UART_LPUART_INTERNAL_CHANNEL,&bytesRemaining)==LPUART_UART_IP_STATUS_BUSY);

	    bufferIdx = 0;
	    // Check the final receiving status
	    lpuartStatus=Lpuart_Uart_Ip_GetReceiveStatus(UART_LPUART_INTERNAL_CHANNEL,&bytesRemaining);

	    if (lpuartStatus!= LPUART_UART_IP_STATUS_SUCCESS)
	    {
	    	// If an error occurred, send the error message and exit the function
	    	Lpuart_Uart_Ip_AsyncSend(UART_LPUART_INTERNAL_CHANNEL, (uint8_t *)ERROR_MSG, strlen(ERROR_MSG));
	        return FAIL;
	    }
}

/* UART send using callback */
void LUART_Send(char Local_Buffer[])
{
	data_length = strlen(Local_Buffer);
   // Lpuart_Uart_Ip_SyncSend(UART_LPUART_INTERNAL_CHANNEL,(unsigned char *)Local_Buffer,data_length,UART_TIMEOUT);
    Lpuart_Uart_Ip_AsyncSend(UART_LPUART_INTERNAL_CHANNEL, (unsigned char *)Local_Buffer, data_length);
}

/* Send BLE commands */
uint8_t Send_Commands(uint8_t index)
{
    memcpy(Send_Buff, Buffer_BLE[index], 13);
    LUART_Send(Send_Buff);
    LUART_Receive();

    if (index == Door_Key)
    {
        if (memcmp(RxBuff, rep, 5) == 0)
        {
            int Max_Count = 0;
            do
            {
                mSec1Flag = false;
                mSec_timer1(1000);
               // while (mSec1Flag != true);
                if (!wait_Flag_Timeout(&mSec1Flag))
                         return FAIL;

                LUART_Send(Send_Buff);
                LUART_Receive();

                if (memcmp(RxBuff, Door_Key_Value, 4) == 0)
                {
                	//mSec1Flag = false;
                    Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 8));
                    mSec1Flag = false;
                    mSec_timer1(1000);
                    //while (mSec1Flag != true);
                    if (!wait_Flag_Timeout(&mSec1Flag))
                         return FAIL;
                    Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 8));
                    memcpy(Send_Buff, Buffer_BLE[Key_reset_DOOR_Key], strlen(Buffer_BLE[Key_reset_DOOR_Key]));
                    LUART_Send(Send_Buff);
                    LUART_Receive();
                    return SUCCESS;
                }
                memset(RxBuff, 0, 13);
                Max_Count++;
            } while (Max_Count < 15);
        }

        if (memcmp(RxBuff, Door_Key_Value, 4) == 0)
        {
        	//mSec1Flag = false;
            Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 8));
            mSec1Flag = false;
            mSec_timer1(1000);
            //while (mSec1Flag != true);
            if (!wait_Flag_Timeout(&mSec1Flag))
                 return FAIL;
            Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 8));
            memcpy(Send_Buff, Buffer_BLE[Key_reset_DOOR_Key], strlen(Buffer_BLE[Key_reset_DOOR_Key]));
            LUART_Send(Send_Buff);
            LUART_Receive();
            return SUCCESS;
        }

        memset(RxBuff, 0, 12);
    }
    else if (index == Vehicle_Key)
    {
        if (memcmp(RxBuff, rep, 5) == 0)
        {
            int Max_Count = 0;
            do
            {
                mSec1Flag = false;
                mSec_timer1(1000);
               // while (mSec1Flag != true);
                if (!wait_Flag_Timeout(&mSec1Flag))
                           return FAIL;

                LUART_Send(Send_Buff);
                LUART_Receive();

                if (memcmp(RxBuff, Vehicle_Key_Value, 6) == 0)
                {
                	//mSec1Flag = false;
                    Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 9));
                    mSec1Flag = false;
                    mSec_timer1(1000);
                    while (mSec1Flag != true);
                              /* if (!wait_Flag_Timeout(&mSec1Flag))
                                	return FAIL;*/

                    Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 9));
                    memcpy(Send_Buff, Buffer_BLE[Key_reset_VEHICLE_Key], strlen(Buffer_BLE[Key_reset_VEHICLE_Key]));
                    LUART_Send(Send_Buff);
                    LUART_Receive();
                    return SUCCESS;
                }
                memset(RxBuff, 0, 12);
                Max_Count++;
            } while (Max_Count < 15);
        }

        if (memcmp(RxBuff, Vehicle_Key_Value, 4) == 0)
        {
        	//mSec1Flag = false;
            Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 9));
            mSec1Flag = false;
            mSec_timer1(1000);
            //while (mSec1Flag != true);
          if (!wait_Flag_Timeout(&mSec1Flag))
            	return FAIL;

            Siul2_Dio_Ip_TogglePins(LED_PORT, (1 << 9));
            memcpy(Send_Buff, Buffer_BLE[Key_reset_VEHICLE_Key], strlen(Buffer_BLE[Key_reset_VEHICLE_Key]));
            LUART_Send(Send_Buff);
            LUART_Receive();
            return SUCCESS;
        }

        memset(RxBuff, 0, 12);
    }
    else
    {
        if (memcmp(RxBuff, Resp_Ble[index], 4) == 0)
        {
            return true;
        }
    }

    return false;
}

/* Door authentication */
uint8_t Door_Auth_key()
{

	response_command = 0;
	if(Reset_flag!=1)
	{
		response_command = Send_Commands(Cmd_Prompt);
	}
    if((response_command == 1)||(Reset_flag==1))
    {
    	Reset_flag=1;
    	response_command = 0;
    	response_command = Send_Commands(Addressing_Mode);
    	if (response_command == 1)
    	{
    		response_command = 0;
    		response_command=Send_Commands(Door_Key);
    	}
    }
	return response_command;
}

/* Vehicle authentication */
uint8_t Vehicle_Auth_key()
{

	response_command = 0;
	if(Reset_flag!=1)
	{
		response_command = Send_Commands(Cmd_Prompt);
	}
    if ((response_command == 1)||(Reset_flag==1))
    {
    	Reset_flag=1;
    	response_command = 0;
    	response_command = Send_Commands(Addressing_Mode);

		if (response_command == 1)
		{
			response_command = 0;
			response_command= Send_Commands(Vehicle_Key);
		}
    }
     return response_command;
}

/* LPUART callback using correct EventType */
void Lpuart_Callback(
    const uint8 HwInstance,
    const Lpuart_Uart_Ip_EventType Event,
    void *UserData
)
{

    (void)HwInstance;
    (void)UserData;

    /* Check the event type */
    if (Event == LPUART_UART_IP_EVENT_RX_FULL)
    {
    	/* The reception stops when newline is received or the buffer is full */
    	if((RxBuff[bufferIdx] != '\n')&&(RxBuff[bufferIdx] != ' ')&&(RxBuff[bufferIdx] != '%'))
    	{
    		bufferIdx++;
    	    Lpuart_Uart_Ip_SetRxBuffer(UART_LPUART_INTERNAL_CHANNEL,&RxBuff[bufferIdx], 1U);
    	    Rx_Buff_Status = 1;  //  indicates that data has been successfully received  and stored in the buffer
    	}
    }
   	 /* Check the event type */
    if (Event == LPUART_UART_IP_EVENT_TX_EMPTY)
    {
    	Resp_Cm = 1;
    }

}

/** @} */
